#include "podspecWithFilesExample.h"

NSString* podspecWithFilesExample() {
    return @"DodspecWithFilesExample";
}
